import React from "react";
import ReactDOM from "react-dom/client";
import PadelHub from "./PadelHub.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PadelHub />
  </React.StrictMode>
);
