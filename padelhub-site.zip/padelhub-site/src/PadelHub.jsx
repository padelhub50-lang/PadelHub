import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  ShoppingBag, X, Plus, Minus, Check, ChevronRight, ChevronLeft,
  Search, MapPin, Package, Phone, Send, Settings, Trash2,
  Lock, LogOut, Star, TrendingUp, Sparkles, Truck,
  AlertCircle, ArrowRight, Save, PlusCircle,
  Zap, Disc, Backpack, Footprints, Shirt, HandMetal, CircleDot, Droplet,
  LayoutGrid, ClipboardList, SlidersHorizontal, Wallet, BellDot, Boxes
} from "lucide-react";

/* =========================================================================
   PADEL HUB — data layer
   ========================================================================= */

const ADMIN_PASSWORD = "padelhub2026";
const DEFAULT_NP_API_KEY = "41fdcf85c0cadb22af055503c40b0459";
const DEFAULT_NP_PROXY_URL = "https://nova-poshtaproxy.padelhub50.workers.dev/";

const ICONS = {
  racket: Zap,
  ball: Disc,
  bag: Backpack,
  shoe: Footprints,
  shirt: Shirt,
  glove: HandMetal,
  grip: CircleDot,
  bottle: Droplet,
};

function ProductIcon({ icon, size = 26 }) {
  const Cmp = ICONS[icon] || CircleDot;
  return <Cmp size={size} strokeWidth={1.8} />;
}

const DEFAULT_PRODUCTS = [
  { id: "p1", name: "Bullpadel Vertex 04", category: "Ракетки", price: 8990, oldPrice: 10490, tag: "Хіт", icon: "racket", desc: "Ракетка топового рівня, форма — сльоза. Контроль + потужність для агресивної гри." , stock: 7},
  { id: "p2", name: "Head Delta Pro", category: "Ракетки", price: 7490, oldPrice: null, tag: "Новинка", icon: "racket", desc: "Кругла форма для максимального контролю. Легка й маневрена.", stock: 12 },
  { id: "p3", name: "Babolat Technical Viper", category: "Ракетки", price: 6290, oldPrice: 7290, tag: "Знижка", icon: "racket", desc: "Універсальна ракетка для гравців середнього рівня.", stock: 5 },
  { id: "p4", name: "Adidas Padel Balls (3 шт)", category: "М'ячі", price: 320, oldPrice: null, tag: null, icon: "ball", desc: "Офіційні м'ячі для тренувань та турнірів.", stock: 40 },
  { id: "p5", name: "Head Padel Pro S", category: "М'ячі", price: 360, oldPrice: null, tag: "Хіт", icon: "ball", desc: "Тур-рівень, підвищена довговічність покриття.", stock: 33 },
  { id: "p6", name: "Bullpadel Vertex Backpack", category: "Сумки", price: 2890, oldPrice: null, tag: null, icon: "bag", desc: "Рюкзак на 2 ракетки з термо-відділенням.", stock: 9 },
  { id: "p7", name: "Head Tour Padel Bag", category: "Сумки", price: 3490, oldPrice: 3990, tag: "Знижка", icon: "bag", desc: "Місткий чохол для ракетки, форми та аксесуарів.", stock: 6 },
  { id: "p8", name: "Asics Gel-Padel Pro", category: "Взуття", price: 4290, oldPrice: null, tag: "Новинка", icon: "shoe", desc: "Кросівки з посиленою боковою підтримкою для різких рухів.", stock: 14 },
  { id: "p9", name: "Padel Hub Performance Tee", category: "Одяг", price: 990, oldPrice: null, tag: null, icon: "shirt", desc: "Дихаюча футболка власної лінії Padel Hub.", stock: 25 },
  { id: "p10", name: "Overgrip Comfort (3 шт)", category: "Аксесуари", price: 250, oldPrice: null, tag: null, icon: "grip", desc: "Обмотка для ракетки, антиковзна, довга зносостійкість.", stock: 60 },
  { id: "p11", name: "Padel Glove Pro", category: "Аксесуари", price: 590, oldPrice: null, tag: null, icon: "glove", desc: "Рукавичка для кращого хвату у вологу погоду.", stock: 18 },
  { id: "p12", name: "Padel Hub Sport Bottle", category: "Аксесуари", price: 350, oldPrice: null, tag: null, icon: "bottle", desc: "Спортивна пляшка 750 мл з логотипом Padel Hub.", stock: 30 },
];

const CATEGORIES = ["Всі", "Ракетки", "М'ячі", "Сумки", "Взуття", "Одяг", "Аксесуари"];

/* Ukrainian settlements dataset for Nova Poshta autocomplete (name + size tier) */
const CITIES = [
  ["Київ","large"],["Харків","large"],["Одеса","large"],["Дніпро","large"],["Львів","large"],
  ["Запоріжжя","large"],["Кривий Ріг","large"],["Миколаїв","large"],["Вінниця","large"],
  ["Полтава","medium"],["Чернігів","medium"],["Черкаси","medium"],["Суми","medium"],
  ["Житомир","medium"],["Хмельницький","medium"],["Чернівці","medium"],["Рівне","medium"],
  ["Кропивницький","medium"],["Івано-Франківськ","medium"],["Тернопіль","medium"],["Луцьк","medium"],
  ["Ужгород","medium"],["Біла Церква","medium"],["Мелітополь","medium"],["Кременчук","medium"],
  ["Бердянськ","medium"],["Слов'янськ","medium"],["Краматорськ","medium"],["Нікополь","small"],
  ["Павлоград","small"],["Кам'янське","medium"],["Олександрія","small"],["Конотоп","small"],
  ["Умань","small"],["Ковель","small"],["Сміла","small"],["Шостка","small"],["Бердичів","small"],
  ["Дрогобич","small"],["Стрий","small"],["Новомосковськ","small"],["Южне","small"],["Ізмаїл","small"],
  ["Болград","small"],["Вишневе","small"],["Ірпінь","medium"],["Буча","small"],["Бровари","medium"],
  ["Бориспіль","small"],["Обухів","small"],["Васильків","small"],["Фастів","small"],["Вишгород","small"],
  ["Вита-Поштова","small"],["Гостомель","small"],["Немішаєве","small"],["Боярка","small"],
  ["Ворзель","small"],["Коцюбинське","small"],
  ["Тростянець","small"],["Ромни","small"],["Прилуки","small"],["Ніжин","small"],["Бахмач","small"],
  ["Козятин","small"],["Жмеринка","small"],["Могилів-Подільський","small"],["Тульчин","small"],
  ["Гайсин","small"],["Калинівка","small"],["Літин","small"],["Хмільник","small"],["Ладижин","small"],
  ["Бершадь","small"],["Шаргород","small"],["Немирів","small"],["Погребище","small"],
  ["Теплик","small"],["Тиврів","small"],["Чечельник","small"],["Ямпіль","small"],
  ["Мукачево","medium"],["Хуст","small"],["Берегове","small"],["Свалява","small"],
  ["Коломия","small"],["Калуш","small"],["Долина","small"],["Яремче","small"],["Косів","small"],
  ["Чортків","small"],["Кременець","small"],["Бучач","small"],["Заліщики","small"],
  ["Дубно","small"],["Костопіль","small"],["Сарни","small"],["Здолбунів","small"],
  ["Володимир","small"],["Нововолинськ","small"],["Камінь-Каширський","small"],
  ["Івановичі","small"],["Гнідин","small"],["Чайки","small"],["Софіївська Борщагівка","small"],
  ["Петропавлівська Борщагівка","small"],["Крюківщина","small"],["Хотів","small"],["Новосілки","small"],
  ["Лісники","small"],["Пирогів","small"],["Стоянка","small"],["Мила","small"],["Юрівка","small"],
  ["Горенка","small"],["Мощун","small"],["Забуччя","small"],["Плюти","small"],["Козин","small"],
].map(([name, tier]) => ({ name, tier }));

const STREETS = [
  "вул. Хрещатик","вул. Соборна","просп. Перемоги","вул. Незалежності","вул. Шевченка",
  "вул. Грушевського","вул. Франка","просп. Свободи","вул. Лесі Українки","вул. Богдана Хмельницького",
  "вул. Гагаріна","вул. Симона Петлюри","вул. Європейська","вул. Соборності","просп. Науки",
  "вул. Центральна","вул. Миру","вул. Вокзальна","вул. Садова"
];

function seededRandom(seed) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) { h = (h * 31 + seed.charCodeAt(i)) >>> 0; }
  return () => {
    h = (h * 1103515245 + 12345) >>> 0;
    return (h % 10000) / 10000;
  };
}

function getBranches(cityName, tier) {
  const counts = { large: 45, medium: 18, small: 5 };
  const n = counts[tier] || 5;
  const rnd = seededRandom(cityName);
  const list = [];
  for (let i = 1; i <= n; i++) {
    const street = STREETS[Math.floor(rnd() * STREETS.length)];
    const num = 1 + Math.floor(rnd() * 180);
    list.push(`Відділення №${i} — ${street}, ${num}`);
  }
  const pomatN = 1500 + Math.floor(rnd() * 8000);
  list.push(`Поштомат №${pomatN} — ${STREETS[Math.floor(rnd() * STREETS.length)]}`);
  return list;
}

/* -------------------------------------------------------------------------
   REAL Nova Poshta API integration.
   The local CITIES/getBranches above are only an offline fallback so the
   store still works with zero setup — they do NOT cover every village or
   every real branch (Nova Poshta has ~30,000 settlements and ~35,000
   branches, far too many to hardcode). Add a free NP API key in
   Керування → Налаштування to switch city & branch search to Nova
   Poshta's live official database — literally every settlement and every
   branch in Ukraine, always up to date.

   Two independent things can block this fetch(), and they look almost
   identical to a user ("Load failed" / "Failed to fetch") but have
   different fixes:

   1. CORS — api.novaposhta.ua sends no Access-Control-Allow-Origin header.
      Fix: call it through a backend/serverless proxy you control (see the
      provided nova-poshta-proxy-worker.js) instead of calling it directly.

   2. The Claude.ai Artifact sandbox itself — Artifacts run in an iframe
      with a fixed Content-Security-Policy whose connect-src does NOT
      allow arbitrary external hosts (only the artifact's own origin, plus
      a small fixed asset allowlist for things like cdnjs). If that's what
      is happening, EVERY fetch() to ANY external host fails identically
      — including calls to your own deployed proxy — and the browser
      usually logs a distinct line to the console:
        "Refused to connect to '...' because it violates the following
         Content Security Policy directive: connect-src ..."
      This is a restriction of the Claude.ai preview environment itself,
      not a bug in this code, and it cannot be worked around from inside
      the artifact — the fix is to host this file outside Claude.ai
      (Vercel, Netlify, your own server, etc.), where no such CSP applies
      and the proxy in nova-poshta-proxy-worker.js will work normally.

   Every attempt below logs its exact URL, request body, HTTP status (if
   any was even reached), full response body, and — if fetch throws — the
   complete error object including its stack trace, so this is fully
   inspectable in DevTools → Console.
   ------------------------------------------------------------------------- */

const NP_ENDPOINT = "https://api.novaposhta.ua/v2.0/json/";
const PUBLIC_CORS_RELAY = "https://corsproxy.io/?url=";

async function npRequest(apiKey, modelName, calledMethod, methodProperties, proxyUrl) {
  const payload = { apiKey, modelName, calledMethod, methodProperties };
  const body = JSON.stringify(payload);

  const attempts = [];
  if (proxyUrl) attempts.push({ label: "custom proxy", url: proxyUrl.trim() });
  attempts.push({ label: "public CORS relay", url: PUBLIC_CORS_RELAY + encodeURIComponent(NP_ENDPOINT) });
  attempts.push({ label: "direct", url: NP_ENDPOINT });

  const failures = [];
  for (const attempt of attempts) {
    const t0 = (typeof performance !== "undefined" ? performance.now() : Date.now());
    console.groupCollapsed(`[NovaPoshta] ${modelName}.${calledMethod} → trying ${attempt.label}`);
    console.log("Request URL:", attempt.url);
    console.log("Request method: POST");
    console.log("Request body (raw):", body);
    console.log("Request body (parsed):", payload);
    try {
      const res = await fetch(attempt.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
      });
      const ms = Math.round((typeof performance !== "undefined" ? performance.now() : Date.now()) - t0);
      console.log(`HTTP status: ${res.status} ${res.statusText}  (${ms}ms)`);
      console.log("Response headers:", Object.fromEntries([...res.headers.entries()]));
      const text = await res.text();
      console.log("Full response body (raw text):", text);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status} ${res.statusText} from ${attempt.label}. Body: ${text.slice(0, 300)}`);
      }

      let data;
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        throw new Error(`Response was not valid JSON (likely an HTML error page from the relay, not Nova Poshta): ${text.slice(0, 300)}`);
      }
      console.log("Full response body (parsed):", data);
      if (!data.success) {
        const msg = (data.errors && data.errors.length && data.errors[0])
          || (data.warnings && data.warnings.length && data.warnings[0])
          || "Nova Poshta API responded with success:false and no error message";
        throw new Error(msg);
      }
      console.log(`%c[NovaPoshta] SUCCESS via ${attempt.label}`, "color:#22C55E;font-weight:bold");
      console.groupEnd();
      return data.data;
    } catch (err) {
      // Log the COMPLETE error object, not just its message, so the real
      // name/message/stack is visible — a CSP block, a CORS block, DNS
      // failure, and a timeout all throw generically-named errors that
      // look the same unless you inspect the full object.
      console.error(`[NovaPoshta] ${attempt.label} threw:`, err);
      console.log("error.name:", err && err.name);
      console.log("error.message:", err && err.message);
      console.log("error.stack:", err && err.stack);
      console.groupEnd();
      failures.push({ label: attempt.label, name: err && err.name, message: err && err.message });
    }
  }

  // Diagnose the pattern: if every single attempt (including different
  // hosts) failed with no HTTP status ever reached, that is the
  // signature of a connect-src CSP block or total loss of network — not
  // an API-key or CORS-on-NP's-side problem, since a plain CORS failure
  // on api.novaposhta.ua would NOT also take down the public relay host.
  const allGenericNetworkFailures = failures.every(f =>
    f.name === "TypeError" && /fetch|load failed|network/i.test(f.message || "")
  );
  console.error("[NovaPoshta] ALL attempts failed:", failures);
  if (allGenericNetworkFailures && failures.length === attempts.length) {
    throw new Error(
      `All ${failures.length} strategies failed with a generic network error before any HTTP response was received ` +
      `(${failures.map(f => `${f.label}: ${f.name}: ${f.message}`).join(" | ")}). ` +
      `This pattern — every host failing identically, including unrelated hosts — usually means the request never ` +
      `left the browser at all. Check DevTools → Console for a line starting "Refused to connect to ... Content ` +
      `Security Policy directive: connect-src". If present, this is the Claude.ai artifact sandbox blocking outbound ` +
      `fetch() to external hosts, not a bug in this integration — it can only be fixed by hosting this file outside ` +
      `Claude.ai (e.g. Vercel/Netlify) where no such CSP applies.`
    );
  }
  throw new Error(failures.map(f => `${f.label}: ${f.name}: ${f.message}`).join(" | "));
}

async function npFetchCities(query, apiKey, proxyUrl) {
  // NOTE: per Nova Poshta's own docs, searchSettlements runs on model "Address" —
  // an earlier version of this file incorrectly called it under "AddressGeneral",
  // which the real API silently rejects. Fixed here.
  const data = await npRequest(apiKey, "Address", "searchSettlements", {
    CityName: query, Limit: 15, Page: 1,
  }, proxyUrl);
  const addresses = (data && data[0] && data[0].Addresses) || [];
  return addresses.map(a => ({
    label: a.Present,
    ref: a.DeliveryCity,
    area: a.Area,
  }));
}

async function npFetchWarehouses(cityRef, query, apiKey, proxyUrl) {
  const data = await npRequest(apiKey, "Address", "getWarehouses", {
    CityRef: cityRef, Page: 1, Limit: 200, FindByString: query || "",
  }, proxyUrl);
  return (data || [])
    .map(w => ({ label: `№${w.Number} — ${w.Description}`, ref: w.Ref }))
    .sort((a, b) => a.label.localeCompare(b.label, "uk", { numeric: true }));
}

/* -------------------------------------------------------------------------
   CONNECTIVITY DIAGNOSTIC — run three separate probes so the exact point
   of failure is visible without needing to read the Network tab by hand:
     1. Plain GET to the proxy (a "simple" request — no preflight, no
        custom headers). If THIS fails, the browser is blocking the
        connection before Nova Poshta, JSON, or POST are even involved.
     2. POST to the proxy with a real Nova Poshta-shaped JSON body — the
        exact request the site actually makes. This has a CORS preflight
        (OPTIONS) because Content-Type: application/json is not a "simple"
        request header.
     3. GET to an unrelated, well-known public API (api.github.com) that
        is definitely reachable from any normal browser tab. If THIS also
        fails, the problem is not the proxy or Nova Poshta at all — it's
        this page/sandbox blocking outbound fetch() to any external host.
   Every probe logs its full URL, method, headers, status, response body,
   and — on failure — the complete error object with name/message/stack.
   ------------------------------------------------------------------------- */

async function probeFetch(label, url, options) {
  const t0 = (typeof performance !== "undefined" ? performance.now() : Date.now());
  console.groupCollapsed(`[Diagnostic] ${label}`);
  console.log("URL:", url);
  console.log("Method:", (options && options.method) || "GET");
  console.log("Headers:", (options && options.headers) || {});
  if (options && options.body) console.log("Body:", options.body);
  try {
    const res = await fetch(url, options);
    const ms = Math.round((typeof performance !== "undefined" ? performance.now() : Date.now()) - t0);
    const text = await res.text();
    console.log(`Status: ${res.status} ${res.statusText} (${ms}ms)`);
    console.log("Response headers:", Object.fromEntries([...res.headers.entries()]));
    console.log("Response body:", text.slice(0, 500));
    console.groupEnd();
    return { label, url, ok: res.ok, status: res.status, statusText: res.statusText, body: text.slice(0, 300), ms };
  } catch (err) {
    const ms = Math.round((typeof performance !== "undefined" ? performance.now() : Date.now()) - t0);
    console.error("Threw:", err);
    console.log("error.name:", err && err.name);
    console.log("error.message:", err && err.message);
    console.log("error.stack:", err && err.stack);
    console.groupEnd();
    return { label, url, ok: false, errorName: (err && err.name) || "Error", errorMessage: (err && err.message) || String(err), ms };
  }
}

async function runConnectivityDiagnostics(proxyUrl) {
  console.log("%c[Diagnostic] Starting connectivity diagnostics…", "color:#FF8A3D;font-weight:bold");
  const results = [];

  results.push(await probeFetch(
    "1. Plain GET to your proxy (no custom headers, no preflight)",
    proxyUrl
  ));

  results.push(await probeFetch(
    "2. POST to your proxy with a real Nova Poshta request body (triggers CORS preflight)",
    proxyUrl,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        apiKey: "diagnostic-test-key",
        modelName: "Address",
        calledMethod: "searchSettlements",
        methodProperties: { CityName: "Київ", Limit: 1 },
      }),
    }
  ));

  results.push(await probeFetch(
    "3. GET to an unrelated public API (api.github.com) — canary for total network block",
    "https://api.github.com/zen"
  ));

  console.log("%c[Diagnostic] Results summary:", "color:#FF8A3D;font-weight:bold", results);
  return results;
}

function normalize(str) {
  return str.toLowerCase().replace(/['’ʼ]/g, "").replace(/\s+/g, " ").trim();
}

function fuzzyFilter(query, list, getLabel) {
  const q = normalize(query);
  if (!q) return list.slice(0, 8);
  const scored = list
    .map(item => {
      const label = normalize(getLabel(item));
      let score = -1;
      if (label.startsWith(q)) score = 0;
      else if (label.split(" ").some(w => w.startsWith(q))) score = 1;
      else if (label.includes(q)) score = 2;
      return { item, score };
    })
    .filter(x => x.score >= 0)
    .sort((a, b) => a.score - b.score);
  return scored.slice(0, 8).map(x => x.item);
}

function uah(n) {
  return new Intl.NumberFormat("uk-UA").format(n) + " ₴";
}

function genOrderId() {
  const d = new Date();
  return `PH-${d.getFullYear().toString().slice(2)}${(d.getMonth()+1).toString().padStart(2,"0")}${d.getDate().toString().padStart(2,"0")}-${Math.floor(1000+Math.random()*9000)}`;
}

/* =========================================================================
   Storage helpers
   window.storage only exists inside the Claude.ai artifact sandbox. When
   this same file is hosted normally (Vercel/Netlify/your own server —
   which is required for the Nova Poshta live API to actually work, since
   the artifact sandbox blocks outbound fetch() to external hosts), there
   is no window.storage, so this falls back to localStorage automatically.
   No code changes needed when moving between the two environments.
   ========================================================================= */

const hasArtifactStorage = typeof window !== "undefined" && !!window.storage;

async function loadShared(key, fallback) {
  try {
    if (hasArtifactStorage) {
      const res = await window.storage.get(key, true);
      if (res && res.value) return JSON.parse(res.value);
    } else if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(key);
      if (raw) return JSON.parse(raw);
    }
  } catch (e) {
    // fall through to seeding below
  }
  await saveShared(key, fallback);
  return fallback;
}
async function saveShared(key, value) {
  try {
    if (hasArtifactStorage) {
      await window.storage.set(key, JSON.stringify(value), true);
    } else if (typeof localStorage !== "undefined") {
      localStorage.setItem(key, JSON.stringify(value));
    }
  } catch (e) {
    console.warn("[Storage] Failed to persist", key, e);
  }
}

/* =========================================================================
   Small reusable components
   ========================================================================= */

function AutoComplete({ value, onChange, source, getLabel, placeholder, onSelect, disabled, icon, hint }) {
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const [asyncResults, setAsyncResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [asyncFailed, setAsyncFailed] = useState(false);
  const [asyncErrorMsg, setAsyncErrorMsg] = useState("");
  const ref = useRef(null);
  const debounceRef = useRef(null);
  const isAsync = typeof source === "function";

  useEffect(() => {
    if (!isAsync) return undefined;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!value || value.trim().length < 2) { setAsyncResults(null); setLoading(false); return undefined; }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await source(value);
        setAsyncResults(res);
        setAsyncFailed(false);
        setAsyncErrorMsg("");
      } catch (e) {
        setAsyncResults(null);
        setAsyncFailed(true);
        setAsyncErrorMsg((e && e.message) ? e.message : String(e));
        console.error("[NovaPoshta] autocomplete lookup failed:", e);
      } finally {
        setLoading(false);
      }
    }, 350);
    return () => clearTimeout(debounceRef.current);
    // eslint-disable-next-line
  }, [value, isAsync]);

  useEffect(() => {
    function onDoc(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const filtered = isAsync ? (asyncResults || []) : fuzzyFilter(value, source || [], getLabel);

  return (
    <div className="ph-autocomplete" ref={ref}>
      <div className={`ph-input-wrap ${disabled ? "ph-disabled" : ""}`}>
        {icon}
        <input
          disabled={disabled}
          value={value}
          placeholder={placeholder}
          onChange={e => { onChange(e.target.value); setOpen(true); setHi(0); }}
          onFocus={() => setOpen(true)}
          onKeyDown={e => {
            if (!open) return;
            if (e.key === "ArrowDown") { e.preventDefault(); setHi(h => Math.min(h + 1, filtered.length - 1)); }
            if (e.key === "ArrowUp") { e.preventDefault(); setHi(h => Math.max(h - 1, 0)); }
            if (e.key === "Enter" && filtered[hi]) { e.preventDefault(); onSelect(filtered[hi]); setOpen(false); }
            if (e.key === "Escape") setOpen(false);
          }}
        />
        {isAsync && loading && <span className="ph-spinner" />}
      </div>
      {open && !disabled && (filtered.length > 0 || (isAsync && (loading || asyncFailed))) && (
        <div className="ph-dropdown">
          {isAsync && loading && <div className="ph-option ph-option-muted">Пошук у Новій пошті…</div>}
          {isAsync && !loading && asyncFailed && (
            <div className="ph-option ph-option-muted ph-option-error">
              Помилка Нової пошти: {asyncErrorMsg.length > 140 ? asyncErrorMsg.slice(0, 140) + "…" : asyncErrorMsg}
              <br />Повний лог — у консолі браузера (F12 → Console).
            </div>
          )}
          {filtered.map((item, i) => (
            <div
              key={getLabel(item) + i}
              className={`ph-option ${i === hi ? "ph-option-hi" : ""}`}
              onMouseEnter={() => setHi(i)}
              onMouseDown={() => { onSelect(item); setOpen(false); }}
            >
              {getLabel(item)}
            </div>
          ))}
        </div>
      )}
      {hint && <div className="ph-field-hint">{hint}</div>}
    </div>
  );
}

function useTilt(maxTilt = 9) {
  const ref = useRef(null);
  const [style, setStyle] = useState({});
  const onMouseMove = useCallback((e) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    const rx = (py - 0.5) * -2 * maxTilt;
    const ry = (px - 0.5) * 2 * maxTilt;
    setStyle({
      transform: `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateZ(6px) scale(1.015)`,
      "--mx": `${px * 100}%`,
      "--my": `${py * 100}%`,
    });
  }, [maxTilt]);
  const onMouseLeave = useCallback(() => {
    setStyle({ transform: "perspective(900px) rotateX(0deg) rotateY(0deg) translateZ(0) scale(1)" });
  }, []);
  return { ref, style, onMouseMove, onMouseLeave };
}

/* =========================================================================
   Main App
   ========================================================================= */

export default function PadelHub() {
  const [products, setProducts] = useState(DEFAULT_PRODUCTS);
  const [orders, setOrders] = useState([]);
  const [settings, setSettings] = useState({
    heroTitle: "Грай на межі можливого",
    heroSubtitle: "Ракетки, м'ячі та екіпірування для падел від Padel Hub — обираємо для перемоги.",
    phone: "+380 50 134 37 88",
    telegram: "@PadelHubManager",
    novaPoshtaApiKey: DEFAULT_NP_API_KEY,
    novaPoshtaProxyUrl: DEFAULT_NP_PROXY_URL,
  });
  const [loaded, setLoaded] = useState(false);

  const [category, setCategory] = useState("Всі");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [orderDone, setOrderDone] = useState(null);

  const [adminOpen, setAdminOpen] = useState(false);
  const [adminAuthed, setAdminAuthed] = useState(false);
  const [adminPwInput, setAdminPwInput] = useState("");
  const [adminTab, setAdminTab] = useState("orders");
  const [pwError, setPwError] = useState(false);

  const [form, setForm] = useState({
    name: "", phone: "", email: "",
    delivery: "np-branch", city: "", cityRef: "", branch: "", branchRef: "", address: "",
    comment: "",
  });

  const anyOverlayOpen = cartOpen || checkoutOpen || adminOpen;
  useEffect(() => {
    if (typeof document === "undefined") return undefined;
    if (anyOverlayOpen) {
      const prevBodyOverflow = document.body.style.overflow;
      const prevHtmlOverflow = document.documentElement.style.overflow;
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prevBodyOverflow;
        document.documentElement.style.overflow = prevHtmlOverflow;
      };
    }
    return undefined;
  }, [anyOverlayOpen]);

  useEffect(() => {
    (async () => {
      const p = await loadShared("ph_products", DEFAULT_PRODUCTS);
      const o = await loadShared("ph_orders", []);
      let s = await loadShared("ph_settings", settings);
      let needsSave = false;
      if (!s.novaPoshtaApiKey) { s = { ...s, novaPoshtaApiKey: DEFAULT_NP_API_KEY }; needsSave = true; }
      if (!s.novaPoshtaProxyUrl) { s = { ...s, novaPoshtaProxyUrl: DEFAULT_NP_PROXY_URL }; needsSave = true; }
      if (needsSave) await saveShared("ph_settings", s);
      setProducts(p); setOrders(o); setSettings(s);
      setLoaded(true);
    })();
    // eslint-disable-next-line
  }, []);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const catOk = category === "Всі" || p.category === category;
      const q = normalize(search);
      const searchOk = !q || normalize(p.name).includes(q) || normalize(p.category).includes(q);
      return catOk && searchOk;
    });
  }, [products, category, search]);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.qty * i.price, 0);
  const newOrdersCount = orders.filter(o => o.status === "new").length;
  const totalRevenue = orders.reduce((s, o) => s + o.total, 0);

  function addToCart(product) {
    setCart(c => {
      const existing = c.find(i => i.id === product.id);
      if (existing) return c.map(i => i.id === product.id ? { ...i, qty: Math.min(i.qty + 1, product.stock) } : i);
      return [...c, { id: product.id, name: product.name, price: product.price, qty: 1, icon: product.icon }];
    });
    setCartOpen(true);
  }
  function updateQty(id, delta) {
    setCart(c => c.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i).filter(i => i.qty > 0));
  }
  function removeFromCart(id) {
    setCart(c => c.filter(i => i.id !== id));
  }

  const npApiKey = (settings.novaPoshtaApiKey || "").trim();
  const npProxyUrl = (settings.novaPoshtaProxyUrl || "").trim();
  const useNpApi = npApiKey.length > 0;

  const cityObj = CITIES.find(c => c.name === form.city);
  const branchOptions = useMemo(() => {
    if (useNpApi) return null;
    if (!cityObj) return [];
    return getBranches(cityObj.name, cityObj.tier);
  }, [cityObj, useNpApi]);

  const citySource = useNpApi ? (q => npFetchCities(q, npApiKey, npProxyUrl)) : CITIES;
  const cityGetLabel = useNpApi ? (item => item.label) : (item => item.name);
  const branchDisabled = useNpApi ? !form.cityRef : !cityObj;
  const branchSource = useNpApi
    ? (form.cityRef ? (q => npFetchWarehouses(form.cityRef, q, npApiKey, npProxyUrl)) : [])
    : (branchOptions || []);
  const branchGetLabel = useNpApi ? (item => item.label) : (item => item);


  function selectCity(item) {
    if (useNpApi) {
      setForm(f => ({ ...f, city: item.label, cityRef: item.ref, branch: "", branchRef: "" }));
    } else {
      setForm(f => ({ ...f, city: item.name, cityRef: "", branch: "", branchRef: "" }));
    }
  }
  function selectBranch(item) {
    if (useNpApi) {
      setForm(f => ({ ...f, branch: item.label, branchRef: item.ref }));
    } else {
      setForm(f => ({ ...f, branch: item }));
    }
  }

  function canGoStep(s) {
    if (s === 1) return cart.length > 0;
    if (s === 2) {
      const contactsOk = form.name.trim().length > 1 && form.phone.trim().length >= 9;
      if (!contactsOk) return false;
      if (form.delivery === "courier") return form.address.trim().length > 3;
      return form.city.trim().length > 0 && form.branch.trim().length > 0;
    }
    return true;
  }

  async function submitOrder() {
    const id = genOrderId();
    const order = {
      id,
      date: new Date().toISOString(),
      items: cart,
      total: cartTotal,
      customer: { name: form.name, phone: form.phone, email: form.email },
      delivery: form.delivery === "courier"
        ? { method: "Кур'єр", address: form.address }
        : { method: form.delivery === "np-pomat" ? "Нова Пошта (поштомат)" : "Нова Пошта (відділення)", city: form.city, branch: form.branch },
      comment: form.comment,
      status: "new",
    };
    const nextOrders = [order, ...orders];
    setOrders(nextOrders);
    await saveShared("ph_orders", nextOrders);

    // decrement stock
    const nextProducts = products.map(p => {
      const inCart = cart.find(i => i.id === p.id);
      return inCart ? { ...p, stock: Math.max(0, p.stock - inCart.qty) } : p;
    });
    setProducts(nextProducts);
    await saveShared("ph_products", nextProducts);

    setOrderDone(order);
    setCart([]);
    setStep(0);
  }

  function closeCheckout() {
    setCheckoutOpen(false);
    setOrderDone(null);
    setStep(0);
  }

  function tryAdminLogin() {
    if (adminPwInput === ADMIN_PASSWORD) {
      setAdminAuthed(true);
      setPwError(false);
    } else {
      setPwError(true);
    }
  }

  async function updateProduct(id, patch) {
    const next = products.map(p => p.id === id ? { ...p, ...patch } : p);
    setProducts(next);
    await saveShared("ph_products", next);
  }
  async function deleteProduct(id) {
    const next = products.filter(p => p.id !== id);
    setProducts(next);
    await saveShared("ph_products", next);
  }
  async function addProduct() {
    const id = "p" + Date.now();
    const next = [{ id, name: "Новий товар", category: "Аксесуари", price: 0, oldPrice: null, tag: null, icon: "grip", desc: "Опис товару", stock: 0 }, ...products];
    setProducts(next);
    await saveShared("ph_products", next);
  }
  async function updateOrderStatus(id, status) {
    const next = orders.map(o => o.id === id ? { ...o, status } : o);
    setOrders(next);
    await saveShared("ph_orders", next);
  }
  async function deleteOrder(id) {
    const next = orders.filter(o => o.id !== id);
    setOrders(next);
    await saveShared("ph_orders", next);
  }
  async function saveSettings(next) {
    setSettings(next);
    await saveShared("ph_settings", next);
  }

  return (
    <div className="ph-root">
      <Styles />
      <CourtBg />

      {/* ---------------- HEADER ---------------- */}
      <header className="ph-header">
        <div className="ph-header-inner">
          <div className="ph-logo">
            <span className="ph-logo-mark">P</span>
            <span className="ph-logo-text">Padel Hub</span>
          </div>
          <nav className="ph-nav">
            {CATEGORIES.map(c => (
              <button
                key={c}
                className={`ph-nav-link ${category === c ? "ph-nav-link-active" : ""}`}
                onClick={() => setCategory(c)}
              >
                {c}
                <span className="ph-nav-underline" />
              </button>
            ))}
          </nav>
          <div className="ph-header-actions">
            <div className="ph-search">
              <Search size={16} />
              <input placeholder="Пошук товару…" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <button className="ph-cart-btn" onClick={() => setCartOpen(true)}>
              <ShoppingBag size={19} />
              {cartCount > 0 && <span className="ph-cart-badge">{cartCount}</span>}
            </button>
          </div>
        </div>
      </header>

      {/* ---------------- HERO ---------------- */}
      <HeroSection settings={settings} />

      {/* ---------------- CATALOG ---------------- */}
      <section id="ph-catalog" className="ph-catalog">
        <div className="ph-section-head">
          <h2>Каталог</h2>
          <div className="ph-chips">
            {CATEGORIES.map(c => (
              <button key={c} className={`ph-chip ${category === c ? "ph-chip-active" : ""}`} onClick={() => setCategory(c)}>
                {c}
              </button>
            ))}
          </div>
        </div>

        {!loaded ? (
          <div className="ph-loading">Завантаження каталогу…</div>
        ) : filteredProducts.length === 0 ? (
          <div className="ph-empty">Нічого не знайдено. Спробуйте інший запит або категорію.</div>
        ) : (
          <div className="ph-grid">
            {filteredProducts.map(p => (
              <ProductCard key={p.id} p={p} onAdd={addToCart} />
            ))}
          </div>
        )}
      </section>

      {/* ---------------- WHY US ---------------- */}
      <section className="ph-why">
        <div className="ph-why-item">
          <Truck size={22} />
          <div>
            <div className="ph-why-title">Доставка по всій Україні</div>
            <div className="ph-why-text">Нова Пошта — відділення, поштомат або кур'єр за адресою.</div>
          </div>
        </div>
        <div className="ph-why-item">
          <Star size={22} />
          <div>
            <div className="ph-why-title">Оригінальна екіпіровка</div>
            <div className="ph-why-text">Тільки перевірені бренди для падел: Bullpadel, Head, Babolat, Adidas.</div>
          </div>
        </div>
        <div className="ph-why-item">
          <Package size={22} />
          <div>
            <div className="ph-why-title">Швидка обробка</div>
            <div className="ph-why-text">Замовлення відправляємо протягом 24 годин після підтвердження.</div>
          </div>
        </div>
      </section>

      {/* ---------------- FOOTER ---------------- */}
      <footer className="ph-footer">
        <ServeLine flip />
        <div className="ph-footer-inner">
          <div className="ph-footer-brand">
            <span className="ph-logo-mark">P</span>
            <span className="ph-logo-text">Padel Hub</span>
          </div>
          <div className="ph-footer-contacts">
            <a className="ph-footer-link" href="tel:+380501343788">
              <Phone size={16} /> {settings.phone}
            </a>
            <a className="ph-footer-link" href="https://t.me/PadelHubManager" target="_blank" rel="noreferrer">
              <Send size={16} /> {settings.telegram}
            </a>
          </div>
          <button className="ph-admin-toggle" onClick={() => setAdminOpen(true)} title="Керування сайтом">
            <Settings size={15} /> Керування
          </button>
        </div>
        <div className="ph-footer-copy">© {new Date().getFullYear()} Padel Hub. Усі права захищено.</div>
      </footer>

      {/* ---------------- CART DRAWER ---------------- */}
      {cartOpen && (
        <div className="ph-overlay" onClick={() => setCartOpen(false)}>
          <div className="ph-drawer" onClick={e => e.stopPropagation()}>
            <div className="ph-drawer-head">
              <h3><ShoppingBag size={18} /> Кошик</h3>
              <button className="ph-icon-btn" onClick={() => setCartOpen(false)}><X size={18} /></button>
            </div>
            {cart.length === 0 ? (
              <div className="ph-empty" style={{ padding: "40px 20px" }}>Кошик порожній. Додайте товари з каталогу.</div>
            ) : (
              <>
                <div className="ph-cart-items">
                  {cart.map(i => (
                    <div className="ph-cart-item" key={i.id}>
                      <span className="ph-cart-item-icon"><ProductIcon icon={i.icon} size={18} /></span>
                      <div className="ph-cart-item-info">
                        <div className="ph-cart-item-name">{i.name}</div>
                        <div className="ph-cart-item-price">{uah(i.price)}</div>
                      </div>
                      <div className="ph-qty">
                        <button onClick={() => updateQty(i.id, -1)}><Minus size={13} /></button>
                        <span>{i.qty}</span>
                        <button onClick={() => updateQty(i.id, 1)}><Plus size={13} /></button>
                      </div>
                      <button className="ph-icon-btn" onClick={() => removeFromCart(i.id)}><Trash2 size={15} /></button>
                    </div>
                  ))}
                </div>
                <div className="ph-drawer-foot">
                  <div className="ph-total-row"><span>Разом</span><span>{uah(cartTotal)}</span></div>
                  <button className="ph-btn ph-btn-primary ph-btn-full" onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}>
                    Оформити замовлення <ChevronRight size={16} />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ---------------- CHECKOUT MODAL ---------------- */}
      {checkoutOpen && (
        <div className="ph-overlay" onClick={closeCheckout}>
          <div className="ph-modal" onClick={e => e.stopPropagation()}>
            <button className="ph-icon-btn ph-modal-close" onClick={closeCheckout}><X size={18} /></button>

            {orderDone ? (
              <div className="ph-order-success">
                <div className="ph-success-icon"><Check size={30} /></div>
                <h3>Замовлення прийнято!</h3>
                <p>Номер замовлення <b>{orderDone.id}</b>. Наш менеджер зв'яжеться з вами найближчим часом для підтвердження.</p>
                <div className="ph-success-box">
                  <div>Сума: <b>{uah(orderDone.total)}</b></div>
                  <div>Доставка: <b>{orderDone.delivery.method}</b></div>
                </div>
                <p className="ph-success-hint">Якщо виникнуть питання — пишіть у Telegram {settings.telegram} або телефонуйте {settings.phone}.</p>
                <button className="ph-btn ph-btn-primary" onClick={closeCheckout}>Продовжити покупки</button>
              </div>
            ) : (
              <>
                <div className="ph-steps">
                  {["Кошик", "Контакти й доставка", "Підтвердження"].map((label, i) => (
                    <div key={label} className={`ph-step ${step === i ? "ph-step-active" : ""} ${step > i ? "ph-step-done" : ""}`}>
                      <span className="ph-step-num">{step > i ? <Check size={12} /> : i + 1}</span>
                      <span>{label}</span>
                    </div>
                  ))}
                </div>

                {step === 0 && (
                  <div className="ph-step-body">
                    <h3>Ваш кошик</h3>
                    <div className="ph-cart-items">
                      {cart.map(i => (
                        <div className="ph-cart-item" key={i.id}>
                          <span className="ph-cart-item-icon"><ProductIcon icon={i.icon} size={18} /></span>
                          <div className="ph-cart-item-info">
                            <div className="ph-cart-item-name">{i.name}</div>
                            <div className="ph-cart-item-price">{uah(i.price)} × {i.qty}</div>
                          </div>
                          <div className="ph-qty">
                            <button onClick={() => updateQty(i.id, -1)}><Minus size={13} /></button>
                            <span>{i.qty}</span>
                            <button onClick={() => updateQty(i.id, 1)}><Plus size={13} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="ph-total-row"><span>Разом</span><span>{uah(cartTotal)}</span></div>
                  </div>
                )}

                {step === 1 && (
                  <div className="ph-step-body">
                    <h3>Контактні дані</h3>
                    <div className="ph-form-grid">
                      <label className="ph-field">
                        <span>Ім'я та прізвище*</span>
                        <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Олена Коваленко" />
                      </label>
                      <label className="ph-field">
                        <span>Телефон*</span>
                        <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+380 XX XXX XX XX" />
                      </label>
                      <label className="ph-field">
                        <span>Email (необов'язково)</span>
                        <input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="example@mail.com" />
                      </label>
                    </div>

                    <h3 style={{ marginTop: 22 }}>Спосіб доставки</h3>
                    <div className="ph-delivery-options">
                      {[
                        { id: "np-branch", label: "Нова Пошта — відділення" },
                        { id: "np-pomat", label: "Нова Пошта — поштомат" },
                        { id: "courier", label: "Кур'єр за адресою" },
                      ].map(opt => (
                        <button
                          key={opt.id}
                          className={`ph-delivery-opt ${form.delivery === opt.id ? "ph-delivery-opt-active" : ""}`}
                          onClick={() => setForm(f => ({ ...f, delivery: opt.id, city: "", cityRef: "", branch: "", branchRef: "" }))}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>

                    {form.delivery !== "courier" ? (
                      <div className="ph-form-grid">
                        <label className="ph-field">
                          <span>Місто*</span>
                          <AutoComplete
                            value={form.city}
                            onChange={v => setForm(f => ({ ...f, city: v, cityRef: "", branch: "", branchRef: "" }))}
                            source={citySource}
                            getLabel={cityGetLabel}
                            placeholder="Почніть вводити назву міста або села…"
                            icon={<MapPin size={15} />}
                            onSelect={selectCity}
                            hint={useNpApi
                              ? <><span className="ph-dot ph-dot-on" /> Живий пошук Нової Пошти — усі міста й села України</>
                              : <><span className="ph-dot ph-dot-off" /> Локальна база (обмежена) — додайте API-ключ Нової Пошти в адмінці для повного списку сіл</>}
                          />
                        </label>
                        <label className="ph-field">
                          <span>{form.delivery === "np-pomat" ? "Поштомат*" : "Відділення*"}</span>
                          <AutoComplete
                            value={form.branch}
                            onChange={v => setForm(f => ({ ...f, branch: v, branchRef: "" }))}
                            source={branchSource}
                            getLabel={branchGetLabel}
                            placeholder={!branchDisabled ? "Почніть вводити номер або вулицю…" : "Спочатку оберіть місто"}
                            disabled={branchDisabled}
                            icon={<Package size={15} />}
                            onSelect={selectBranch}
                            hint={useNpApi ? <><span className="ph-dot ph-dot-on" /> Усі реальні відділення й поштомати цього міста</> : null}
                          />
                        </label>
                      </div>
                    ) : (
                      <label className="ph-field">
                        <span>Адреса доставки*</span>
                        <input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="Місто, вулиця, будинок, квартира" />
                      </label>
                    )}

                    <label className="ph-field" style={{ marginTop: 12 }}>
                      <span>Коментар до замовлення</span>
                      <input value={form.comment} onChange={e => setForm(f => ({ ...f, comment: e.target.value }))} placeholder="Необов'язково" />
                    </label>
                  </div>
                )}

                {step === 2 && (
                  <div className="ph-step-body">
                    <h3>Перевірте замовлення</h3>
                    <div className="ph-summary">
                      <div className="ph-summary-row"><span>Ім'я</span><b>{form.name}</b></div>
                      <div className="ph-summary-row"><span>Телефон</span><b>{form.phone}</b></div>
                      {form.email && <div className="ph-summary-row"><span>Email</span><b>{form.email}</b></div>}
                      <div className="ph-summary-row"><span>Доставка</span><b>{form.delivery === "courier" ? "Кур'єр" : form.delivery === "np-pomat" ? "Нова Пошта, поштомат" : "Нова Пошта, відділення"}</b></div>
                      {form.delivery !== "courier" ? (
                        <>
                          <div className="ph-summary-row"><span>Місто</span><b>{form.city}</b></div>
                          <div className="ph-summary-row"><span>Відділення</span><b>{form.branch}</b></div>
                        </>
                      ) : (
                        <div className="ph-summary-row"><span>Адреса</span><b>{form.address}</b></div>
                      )}
                    </div>
                    <div className="ph-cart-items">
                      {cart.map(i => (
                        <div className="ph-cart-item" key={i.id}>
                          <span className="ph-cart-item-icon"><ProductIcon icon={i.icon} size={18} /></span>
                          <div className="ph-cart-item-info">
                            <div className="ph-cart-item-name">{i.name}</div>
                            <div className="ph-cart-item-price">{uah(i.price)} × {i.qty}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="ph-total-row"><span>До сплати (при отриманні)</span><span>{uah(cartTotal)}</span></div>
                  </div>
                )}

                <div className="ph-step-nav">
                  {step > 0 && (
                    <button className="ph-btn ph-btn-ghost" onClick={() => setStep(s => s - 1)}>
                      <ChevronLeft size={16} /> Назад
                    </button>
                  )}
                  {step < 2 ? (
                    <button className="ph-btn ph-btn-primary" disabled={!canGoStep(step + 1)} onClick={() => setStep(s => s + 1)}>
                      Далі <ChevronRight size={16} />
                    </button>
                  ) : (
                    <button className="ph-btn ph-btn-primary" onClick={submitOrder}>
                      Підтвердити замовлення <Check size={16} />
                    </button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ---------------- ADMIN ---------------- */}
      {adminOpen && (
        <div className="ph-overlay" onClick={() => { setAdminOpen(false); }}>
          <div className={`ph-modal ${adminAuthed ? "ph-admin-modal" : ""}`} onClick={e => e.stopPropagation()}>
            <button className="ph-icon-btn ph-modal-close" onClick={() => setAdminOpen(false)}><X size={18} /></button>
            {!adminAuthed ? (
              <div className="ph-admin-login">
                <Lock size={26} />
                <h3>Вхід для керування сайтом</h3>
                <input
                  type="password"
                  placeholder="Пароль адміністратора"
                  value={adminPwInput}
                  onChange={e => { setAdminPwInput(e.target.value); setPwError(false); }}
                  onKeyDown={e => e.key === "Enter" && tryAdminLogin()}
                />
                {pwError && <div className="ph-pw-error"><AlertCircle size={14} /> Невірний пароль</div>}
                <button className="ph-btn ph-btn-primary" onClick={tryAdminLogin}>Увійти</button>
              </div>
            ) : (
              <div className="ph-admin-shell">
                <aside className="ph-admin-sidebar">
                  <div className="ph-admin-brand">
                    <span className="ph-logo-mark">P</span>
                    <div>
                      <div className="ph-admin-brand-name">Padel Hub</div>
                      <div className="ph-admin-brand-sub">Керування сайтом</div>
                    </div>
                  </div>
                  <nav className="ph-admin-nav">
                    <button className={adminTab === "orders" ? "ph-admin-nav-active" : ""} onClick={() => setAdminTab("orders")}>
                      <ClipboardList size={17} /> Замовлення
                      {newOrdersCount > 0 && <span className="ph-nav-badge">{newOrdersCount}</span>}
                    </button>
                    <button className={adminTab === "products" ? "ph-admin-nav-active" : ""} onClick={() => setAdminTab("products")}>
                      <Boxes size={17} /> Товари
                    </button>
                    <button className={adminTab === "settings" ? "ph-admin-nav-active" : ""} onClick={() => setAdminTab("settings")}>
                      <SlidersHorizontal size={17} /> Налаштування
                    </button>
                  </nav>
                  <button className="ph-admin-logout" onClick={() => { setAdminAuthed(false); setAdminPwInput(""); }}>
                    <LogOut size={15} /> Вийти
                  </button>
                </aside>

                <div className="ph-admin-main">
                  <div className="ph-admin-stats">
                    <div className="ph-stat-card">
                      <ClipboardList size={16} />
                      <div><span>Усього замовлень</span><b>{orders.length}</b></div>
                    </div>
                    <div className="ph-stat-card ph-stat-accent">
                      <BellDot size={16} />
                      <div><span>Нові, не оброблені</span><b>{newOrdersCount}</b></div>
                    </div>
                    <div className="ph-stat-card">
                      <Wallet size={16} />
                      <div><span>Виручка (всі замовлення)</span><b>{uah(totalRevenue)}</b></div>
                    </div>
                    <div className="ph-stat-card">
                      <LayoutGrid size={16} />
                      <div><span>Товарів у каталозі</span><b>{products.length}</b></div>
                    </div>
                  </div>

                  <div className="ph-admin-panel-title">
                    {adminTab === "orders" && <><ClipboardList size={16} /> Замовлення від клієнтів</>}
                    {adminTab === "products" && <><Boxes size={16} /> Товари й ціни</>}
                    {adminTab === "settings" && <><SlidersHorizontal size={16} /> Налаштування сайту</>}
                  </div>

                  {adminTab === "orders" && (
                    <div className="ph-admin-body">
                      {orders.length === 0 ? (
                        <div className="ph-empty">Замовлень поки немає. Щойно клієнт оформить покупку — вона з'явиться тут.</div>
                      ) : orders.map(o => (
                        <div className="ph-order-card" key={o.id}>
                          <div className="ph-order-top">
                            <div>
                              <b>{o.id}</b>
                              <span className="ph-order-date">{new Date(o.date).toLocaleString("uk-UA")}</span>
                            </div>
                            <label className="ph-status-label">
                              <span>Статус</span>
                              <select value={o.status} onChange={e => updateOrderStatus(o.id, e.target.value)} className={`ph-status ph-status-${o.status}`}>
                                <option value="new">Нове</option>
                                <option value="confirmed">Підтверджено</option>
                                <option value="shipped">Відправлено</option>
                                <option value="done">Завершено</option>
                              </select>
                            </label>
                          </div>
                          <div className="ph-order-grid">
                            <div><span>Клієнт</span><b>{o.customer.name}</b></div>
                            <div><span>Телефон</span><b>{o.customer.phone}</b></div>
                            {o.customer.email && <div><span>Email</span><b>{o.customer.email}</b></div>}
                            <div><span>Доставка</span><b>{o.delivery.method}</b></div>
                            {o.delivery.city && <div><span>Місто</span><b>{o.delivery.city}</b></div>}
                            {o.delivery.branch && <div><span>Відділення</span><b>{o.delivery.branch}</b></div>}
                            {o.delivery.address && <div><span>Адреса</span><b>{o.delivery.address}</b></div>}
                          </div>
                          <div className="ph-order-items">
                            {o.items.map(i => (
                              <div key={i.id} className="ph-order-item-row"><ProductIcon icon={i.icon} size={14} /> {i.name} × {i.qty} — {uah(i.price * i.qty)}</div>
                            ))}
                          </div>
                          {o.comment && <div className="ph-order-comment">Коментар: {o.comment}</div>}
                          <div className="ph-order-bottom">
                            <b>Разом: {uah(o.total)}</b>
                            <button className="ph-icon-btn" onClick={() => deleteOrder(o.id)} title="Видалити замовлення"><Trash2 size={15} /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {adminTab === "products" && (
                    <div className="ph-admin-body">
                      <button className="ph-btn ph-btn-ghost" onClick={addProduct} style={{ marginBottom: 4, alignSelf: "flex-start" }}>
                        <PlusCircle size={15} /> Додати новий товар
                      </button>
                      {products.map(p => (
                        <div className="ph-product-edit" key={p.id}>
                          <span className="ph-product-edit-icon"><ProductIcon icon={p.icon} size={20} /></span>
                          <div className="ph-product-edit-fields">
                            <label className="ph-mini-field ph-mini-field-wide"><span>Назва товару</span>
                              <input value={p.name} onChange={e => updateProduct(p.id, { name: e.target.value })} />
                            </label>
                            <label className="ph-mini-field"><span>Категорія</span>
                              <select value={p.category} onChange={e => updateProduct(p.id, { category: e.target.value })}>
                                {CATEGORIES.filter(c => c !== "Всі").map(c => <option key={c} value={c}>{c}</option>)}
                              </select>
                            </label>
                            <label className="ph-mini-field"><span>Мітка</span>
                              <select value={p.tag || ""} onChange={e => updateProduct(p.id, { tag: e.target.value || null })}>
                                <option value="">Без мітки</option>
                                <option value="Новинка">Новинка</option>
                                <option value="Хіт">Хіт</option>
                                <option value="Знижка">Знижка</option>
                              </select>
                            </label>
                            <label className="ph-mini-field"><span>Ціна, ₴</span>
                              <input type="number" value={p.price} onChange={e => updateProduct(p.id, { price: Number(e.target.value) })} placeholder="0" />
                            </label>
                            <label className="ph-mini-field"><span>Стара ціна, ₴</span>
                              <input type="number" value={p.oldPrice || ""} onChange={e => updateProduct(p.id, { oldPrice: e.target.value ? Number(e.target.value) : null })} placeholder="Немає" />
                            </label>
                            <label className="ph-mini-field"><span>Залишок, шт</span>
                              <input type="number" value={p.stock} onChange={e => updateProduct(p.id, { stock: Number(e.target.value) })} placeholder="0" />
                            </label>
                            <label className="ph-mini-field ph-mini-field-wide"><span>Опис товару</span>
                              <textarea value={p.desc} onChange={e => updateProduct(p.id, { desc: e.target.value })} placeholder="Короткий опис для картки товару" />
                            </label>
                          </div>
                          <button className="ph-icon-btn" onClick={() => deleteProduct(p.id)} title="Видалити товар"><Trash2 size={15} /></button>
                        </div>
                      ))}
                    </div>
                  )}

                  {adminTab === "settings" && (
                    <SettingsForm settings={settings} onSave={saveSettings} />
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ProductCard({ p, onAdd }) {
  const tilt = useTilt(8);
  return (
    <div
      className="ph-card"
      ref={tilt.ref}
      style={tilt.style}
      onMouseMove={tilt.onMouseMove}
      onMouseLeave={tilt.onMouseLeave}
    >
      <div className="ph-card-glare" />
      {p.tag && <span className={`ph-tag ph-tag-${p.tag === "Знижка" ? "sale" : p.tag === "Новинка" ? "new" : "hit"}`}>{p.tag}</span>}
      <div className="ph-card-media">
        <span className="ph-card-icon-badge"><ProductIcon icon={p.icon} size={26} /></span>
      </div>
      <div className="ph-card-body">
        <div className="ph-card-cat">{p.category}</div>
        <div className="ph-card-name">{p.name}</div>
        <div className="ph-card-desc">{p.desc}</div>
        <div className="ph-card-bottom">
          <div className="ph-price-block">
            {p.oldPrice && <span className="ph-old-price">{uah(p.oldPrice)}</span>}
            <span className="ph-price">{uah(p.price)}</span>
          </div>
          <button
            className="ph-btn ph-btn-add"
            disabled={p.stock <= 0}
            onClick={() => onAdd(p)}
          >
            {p.stock <= 0 ? "Немає в наявності" : <>+ Додати</>}
          </button>
        </div>
        {p.stock > 0 && p.stock <= 5 && <div className="ph-stock-low">Залишилось: {p.stock} шт</div>}
      </div>
    </div>
  );
}

function DiagnosticsPanel({ proxyUrl }) {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);

  async function run() {
    if (!proxyUrl || !proxyUrl.trim()) {
      setResults([{ label: "URL проксі не вказано", ok: false, errorMessage: "Спочатку введіть і збережіть URL власного проксі вище." }]);
      return;
    }
    setRunning(true);
    setResults(null);
    const r = await runConnectivityDiagnostics(proxyUrl.trim());
    setResults(r);
    setRunning(false);
  }

  return (
    <div className="ph-diag">
      <button className="ph-btn ph-btn-ghost" onClick={run} disabled={running}>
        <Zap size={15} /> {running ? "Перевіряю…" : "Запустити діагностику"}
      </button>
      {results && (
        <div className="ph-diag-results">
          {results.map((r, i) => (
            <div key={i} className={`ph-diag-row ${r.ok ? "ph-diag-ok" : "ph-diag-fail"}`}>
              <div className="ph-diag-row-head">
                {r.ok ? <Check size={14} /> : <X size={14} />}
                <b>{r.label}</b>
              </div>
              <div className="ph-diag-row-detail">
                <div>URL: <code>{r.url}</code></div>
                {r.ok ? (
                  <>
                    <div>Статус: <code>{r.status} {r.statusText}</code> ({r.ms}ms)</div>
                    <div>Тіло відповіді: <code>{r.body || "(порожнє)"}</code></div>
                  </>
                ) : (
                  <>
                    <div>Тип помилки: <code>{r.errorName}</code></div>
                    <div>Повідомлення: <code>{r.errorMessage}</code></div>
                    <div>Час до збою: <code>{r.ms}ms</code></div>
                  </>
                )}
              </div>
            </div>
          ))}
          <p className="ph-np-hint">
            Якщо тест №3 (стороннє API) теж провалився з тією самою помилкою — з'єднання блокується на рівні
            цієї сторінки/пісочниці, а не проксі чи Нової Пошти, і жоден код тут це не виправить: сайт треба
            відкрити поза Claude.ai (Vercel, Netlify, власний хостинг). Якщо провалились лише тести №1–2, а
            №3 пройшов — проблема саме в проксі (перевірте, що він задеплоєний і URL точний).
          </p>
        </div>
      )}
    </div>
  );
}

function SettingsForm({ settings, onSave }) {
  const [local, setLocal] = useState(settings);
  const [saved, setSaved] = useState(false);
  return (
    <div className="ph-admin-body">
      <label className="ph-field">
        <span>Заголовок на головній</span>
        <input value={local.heroTitle} onChange={e => setLocal(l => ({ ...l, heroTitle: e.target.value }))} />
      </label>
      <label className="ph-field">
        <span>Підзаголовок</span>
        <textarea value={local.heroSubtitle} onChange={e => setLocal(l => ({ ...l, heroSubtitle: e.target.value }))} />
      </label>
      <label className="ph-field">
        <span>Телефон у футері</span>
        <input value={local.phone} onChange={e => setLocal(l => ({ ...l, phone: e.target.value }))} />
      </label>
      <label className="ph-field">
        <span>Telegram у футері</span>
        <input value={local.telegram} onChange={e => setLocal(l => ({ ...l, telegram: e.target.value }))} />
      </label>

      <div className="ph-np-box">
        <div className="ph-np-box-title"><Package size={15} /> API-ключ Нової Пошти</div>
        <p>
          Локальна база міст/відділень у сайті — обмежена (для роботи "з коробки" без налаштувань).
          Щоб пошук показував <b>абсолютно всі міста та села України та всі реальні відділення й поштомати</b> —
          вставте сюди безкоштовний API-ключ Нової Пошти. Отримати його: увійдіть на <b>new.novaposhta.ua</b> →
          Особистий кабінет → «Налаштування» → «API» → скопіюйте ключ (2 хвилини, безкоштовно).
        </p>
        <label className="ph-field">
          <span>API-ключ</span>
          <input
            value={local.novaPoshtaApiKey || ""}
            onChange={e => setLocal(l => ({ ...l, novaPoshtaApiKey: e.target.value }))}
            placeholder="Вставте ключ з кабінету Нової Пошти"
          />
        </label>
        {local.novaPoshtaApiKey ? (
          <div className="ph-np-status ph-np-on"><Check size={13} /> Живий пошук Нової Пошти увімкнено</div>
        ) : (
          <div className="ph-np-status ph-np-off"><AlertCircle size={13} /> Зараз використовується обмежена локальна база</div>
        )}

        <div className="ph-np-divider" />

        <div className="ph-np-box-title"><AlertCircle size={15} /> Важливо: CORS</div>
        <p>
          Сервер Нової Пошти не дозволяє браузеру звертатись до нього напряму (не надсилає CORS-заголовки) —
          це обмеження на їхній стороні, не помилка сайту. Зараз запити йдуть через тимчасовий публічний
          CORS-проксі, щоб усе працювало без додаткових налаштувань. Для стабільної роботи в бойовому режимі
          рекомендуємо розгорнути власну проксі-функцію (Cloudflare Worker / Vercel Function — безкоштовно,
          5 хвилин) і вказати її адресу нижче — сайт спробує звернутись до неї першою, і лише якщо вона
          недоступна — автоматично відкотиться до публічного проксі.
        </p>
        <label className="ph-field">
          <span>URL власного проксі (опційно)</span>
          <input
            value={local.novaPoshtaProxyUrl || ""}
            onChange={e => setLocal(l => ({ ...l, novaPoshtaProxyUrl: e.target.value }))}
            placeholder="https://your-proxy.example.workers.dev"
          />
        </label>
        <p className="ph-np-hint">Повний запит і відповідь кожного звернення до Нової Пошти видно в консолі браузера (F12 → Console).</p>

        <div className="ph-np-divider" />

        <div className="ph-np-box-title"><Zap size={15} /> Діагностика з'єднання</div>
        <p>
          Запускає 3 окремі перевірки: (1) простий GET до вашого проксі, (2) POST-запит до нього так само,
          як робить сайт, (3) запит до стороннього публічного API як "канарка" — щоб побачити, чи блокується
          взагалі будь-яке зовнішнє з'єднання зі сторінки, а не тільки Нова Пошта.
        </p>
        <DiagnosticsPanel proxyUrl={local.novaPoshtaProxyUrl} />
      </div>

      <button className="ph-btn ph-btn-primary" onClick={() => { onSave(local); setSaved(true); setTimeout(() => setSaved(false), 1800); }}>
        <Save size={15} /> Зберегти
      </button>
      {saved && <div className="ph-saved-note"><Check size={14} /> Збережено</div>}
    </div>
  );
}

function HeroSection({ settings }) {
  const wrapRef = useRef(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });

  function onMove(e) {
    const el = wrapRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setParallax({ x: px, y: py });
  }
  function onLeave() { setParallax({ x: 0, y: 0 }); }

  return (
    <section className="ph-hero" ref={wrapRef} onMouseMove={onMove} onMouseLeave={onLeave}>
      <RacketSilhouette parallax={parallax} />
      <div
        className="ph-hero-content"
        style={{ transform: `perspective(1200px) rotateX(${parallax.y * -2}deg) rotateY(${parallax.x * 2}deg)` }}
      >
        <div className="ph-eyebrow"><Sparkles size={14} /> Екіпірування для падел</div>
        <h1 className="ph-hero-title">{settings.heroTitle}</h1>
        <p className="ph-hero-sub">{settings.heroSubtitle}</p>
        <div className="ph-hero-actions">
          <button className="ph-btn ph-btn-primary" onClick={() => document.getElementById("ph-catalog").scrollIntoView({ behavior: "smooth" })}>
            Обрати екіпірування <ArrowRight size={16} />
          </button>
          <div className="ph-hero-stat">
            <TrendingUp size={16} />
            <span>Понад 500 виконаних замовлень</span>
          </div>
        </div>
      </div>
      <ServeLine />
    </section>
  );
}

const RACKET_HOLES = (() => {
  const holes = [];
  const cx0 = 250, cy0 = 250, rx = 150, ry = 178;
  for (let y = cy0 - ry; y <= cy0 + ry; y += 32) {
    for (let x = cx0 - rx; x <= cx0 + rx; x += 32) {
      const dx = (x - cx0) / (rx - 18);
      const dy = (y - cy0) / (ry - 18);
      if (dx * dx + dy * dy < 0.82) holes.push({ cx: x, cy: y });
    }
  }
  return holes;
})();

function RacketSilhouette({ parallax }) {
  const px = parallax?.x || 0;
  const py = parallax?.y || 0;
  return (
    <div className="ph-racket-idle" aria-hidden="true">
      <div
        className="ph-racket-wrap"
        style={{
          transform: `translate3d(${px * 22}px, ${py * 16}px, 0) perspective(1400px) rotateX(${py * -7}deg) rotateY(${px * 7}deg)`,
        }}
      >
        <svg viewBox="0 0 500 800" className="ph-racket-svg">
          <defs>
            <mask id="ph-racket-mask">
              <rect x="0" y="0" width="500" height="800" fill="#fff" />
              {RACKET_HOLES.map((h, i) => <circle key={i} cx={h.cx} cy={h.cy} r="8" fill="#000" />)}
            </mask>
          </defs>
          <g mask="url(#ph-racket-mask)">
            <rect x="72" y="35" width="356" height="425" rx="176" ry="192" className="ph-racket-fill" />
          </g>
          <path d="M 198 452 L 302 452 L 272 516 L 228 516 Z" className="ph-racket-fill" />
          <rect x="212" y="506" width="76" height="248" rx="30" className="ph-racket-fill" />
          <rect x="224" y="524" width="52" height="118" rx="12" className="ph-racket-grip" />
        </svg>
      </div>
    </div>
  );
}

function ServeLine({ flip }) {
  return (
    <svg className={`ph-serve-line ${flip ? "ph-serve-line-flip" : ""}`} viewBox="0 0 1200 80" preserveAspectRatio="none">
      <path d="M0,60 C200,10 400,90 600,40 C800,-10 1000,70 1200,20" fill="none" stroke="url(#ph-grad)" strokeWidth="2" strokeDasharray="6 10" />
      <defs>
        <linearGradient id="ph-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#FF7A2E" stopOpacity="0" />
          <stop offset="50%" stopColor="#FF7A2E" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#FF7A2E" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function CourtBg() {
  return (
    <div className="ph-court-bg" aria-hidden="true">
      <div className="ph-court-glow" />
    </div>
  );
}

function Styles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600&display=swap');

      .ph-root {
        --bg:#0A0806; --bg2:#161009; --bg3:#1F1710; --line:rgba(255,255,255,0.09);
        --orange:#FF5A1F; --orange2:#FF8A3D; --rust:#B33A0E; --gold:#FFC369;
        --text:#F3EAE0; --muted:#9C8B7A;
        font-family:'Manrope',sans-serif; color:var(--text); background:var(--bg);
        position:relative; overflow-x:hidden; min-height:100vh;
      }
      .ph-root *{ box-sizing:border-box; }
      .ph-root h1,.ph-root h2,.ph-root h3{ font-family:'Oswald',sans-serif; letter-spacing:0.01em; margin:0; }

      .ph-court-bg{ position:fixed; inset:0; z-index:-1; pointer-events:none;
        background: radial-gradient(circle at 15% -10%, rgba(255,90,31,0.10), transparent 42%), var(--bg); }
      .ph-court-glow{ position:absolute; top:-10%; right:-10%; width:600px; height:600px; border-radius:50%;
        background: radial-gradient(circle, rgba(255,138,61,0.10), transparent 70%); }

      /* ---------- header ---------- */
      .ph-header{ position:sticky; top:0; z-index:40; background:rgba(20,17,14,0.92); backdrop-filter:blur(10px); border-bottom:1px solid var(--line); }
      .ph-header-inner{ max-width:1240px; margin:0 auto; padding:14px 28px; display:flex; align-items:center; gap:28px; }
      .ph-logo{ display:flex; align-items:center; gap:8px; color:#fff; font-family:'Oswald',sans-serif; font-size:19px; font-weight:600; flex-shrink:0; }
      .ph-logo-mark{ width:30px; height:30px; border-radius:9px; display:flex; align-items:center; justify-content:center;
        background:linear-gradient(135deg,var(--orange),var(--rust)); font-weight:700; font-size:15px; color:#fff; }
      .ph-nav{ display:flex; gap:4px; flex:1; }
      .ph-nav-link{ position:relative; background:none; border:none; color:#cabfb3; font-family:'Manrope',sans-serif; font-weight:600;
        font-size:13.5px; padding:8px 12px; cursor:pointer; transition:color .25s ease; }
      .ph-nav-link:hover{ color:#fff; }
      .ph-nav-link-active{ color:#fff; }
      .ph-nav-underline{ position:absolute; left:12px; right:12px; bottom:3px; height:2px; border-radius:2px;
        background:linear-gradient(90deg,var(--orange),var(--gold)); transform:scaleX(0); transform-origin:left; transition:transform .3s cubic-bezier(.4,0,.2,1); }
      .ph-nav-link:hover .ph-nav-underline, .ph-nav-link-active .ph-nav-underline{ transform:scaleX(1); }
      .ph-header-actions{ display:flex; align-items:center; gap:14px; }
      .ph-search{ display:flex; align-items:center; gap:8px; background:rgba(255,255,255,0.06); border:1px solid var(--line); border-radius:10px;
        padding:7px 12px; color:#cabfb3; transition:border-color .2s ease, background .2s ease; }
      .ph-search:focus-within{ border-color:var(--orange); background:rgba(255,255,255,0.09); }
      .ph-search input{ background:none; border:none; outline:none; color:#fff; font-size:13px; width:150px; }
      .ph-search input::placeholder{ color:#8a7a6c; }
      .ph-cart-btn{ position:relative; background:rgba(255,255,255,0.06); border:1px solid var(--line); color:#fff; width:38px; height:38px;
        border-radius:10px; display:flex; align-items:center; justify-content:center; cursor:pointer; transition:transform .2s ease, background .2s ease, box-shadow .25s ease; }
      .ph-cart-btn:hover{ background:linear-gradient(135deg,var(--orange),var(--rust)); transform:translateY(-2px); box-shadow:0 8px 20px rgba(255,90,31,0.35); }
      .ph-cart-badge{ position:absolute; top:-6px; right:-6px; background:var(--gold); color:#221B15; font-size:10.5px; font-weight:800;
        width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; }

      /* ---------- hero ---------- */
      .ph-hero{ position:relative; padding:100px 28px 90px; background:linear-gradient(160deg,#181310 0%, #221208 55%, #3A1305 100%); overflow:hidden; perspective:1200px; }
      .ph-hero-content{ max-width:720px; margin:0 auto; text-align:center; position:relative; z-index:2; transition:transform .15s ease-out; transform-style:preserve-3d; }
      .ph-eyebrow{ display:inline-flex; align-items:center; gap:6px; color:var(--gold); font-size:12.5px; font-weight:700; letter-spacing:0.08em;
        text-transform:uppercase; background:rgba(255,184,77,0.1); border:1px solid rgba(255,184,77,0.25); padding:6px 14px; border-radius:100px; margin-bottom:22px; }
      .ph-hero-title{ font-size:52px; font-weight:700; color:#fff; line-height:1.08; margin-bottom:18px; text-shadow:0 12px 30px rgba(0,0,0,0.35); }
      .ph-hero-sub{ color:#cabfb3; font-size:16.5px; line-height:1.6; max-width:520px; margin:0 auto 34px; }
      .ph-hero-actions{ display:flex; flex-direction:column; align-items:center; gap:18px; }
      .ph-hero-stat{ display:flex; align-items:center; gap:7px; color:#a8998a; font-size:13px; }
      .ph-serve-line{ position:absolute; left:0; right:0; bottom:0; width:100%; height:60px; }
      .ph-serve-line-flip{ transform:scaleY(-1); top:0; bottom:auto; }

      .ph-racket-idle{ position:absolute; inset:0; z-index:1; pointer-events:none; overflow:hidden; animation:ph-racket-sway 11s ease-in-out infinite; transform-origin:70% 45%; }
      .ph-racket-wrap{ position:absolute; top:50%; right:-8%; height:150%; width:auto; transform-style:preserve-3d;
        transition:transform .5s cubic-bezier(.2,.8,.2,1); margin-top:-75%;
        filter:drop-shadow(18px 26px 30px rgba(0,0,0,0.55)) drop-shadow(0 0 60px rgba(255,90,31,0.14)); }
      .ph-racket-svg{ height:100%; width:auto; display:block; }
      .ph-racket-fill{ fill:rgba(6,4,3,0.72); stroke:rgba(255,122,46,0.32); stroke-width:2; }
      .ph-racket-grip{ fill:rgba(255,138,61,0.16); stroke:rgba(255,122,46,0.28); stroke-width:1.5; }
      @keyframes ph-racket-sway{ 0%,100%{ transform:rotate(-2.2deg) translateY(0); } 50%{ transform:rotate(1.4deg) translateY(-10px); } }


      /* ---------- buttons ---------- */
      .ph-btn{ font-family:'Manrope',sans-serif; font-weight:700; font-size:14px; border:none; cursor:pointer; border-radius:11px;
        padding:13px 22px; display:inline-flex; align-items:center; justify-content:center; gap:8px; transition:transform .12s ease, box-shadow .25s ease, background .2s ease; transform-style:preserve-3d; }
      .ph-btn-primary{ background:linear-gradient(135deg,var(--orange),var(--rust)); color:#fff; box-shadow:0 6px 0 var(--rust), 0 14px 26px rgba(255,90,31,0.32); }
      .ph-btn-primary:hover{ transform:translateY(-3px); box-shadow:0 9px 0 var(--rust), 0 18px 32px rgba(255,90,31,0.42); }
      .ph-btn-primary:active{ transform:translateY(3px); box-shadow:0 2px 0 var(--rust), 0 6px 14px rgba(255,90,31,0.3); }
      .ph-btn-primary:disabled{ opacity:0.4; cursor:not-allowed; transform:none; box-shadow:none; }
      .ph-btn-ghost{ background:rgba(255,255,255,0.06); color:var(--text); }
      .ph-btn-ghost:hover{ background:rgba(255,255,255,0.11); }
      .ph-btn-full{ width:100%; }
      .ph-btn-add{ background:var(--bg2); color:#fff; font-size:12.5px; padding:9px 14px; border-radius:9px; box-shadow:0 4px 0 #000; }
      .ph-btn-add:hover{ background:linear-gradient(135deg,var(--orange),var(--rust)); transform:translateY(-2px); box-shadow:0 6px 0 var(--rust); }
      .ph-btn-add:active{ transform:translateY(2px); box-shadow:0 2px 0 var(--rust); }
      .ph-btn-add:disabled{ background:#d8cfc5; color:#8a7a6c; cursor:not-allowed; box-shadow:none; transform:none; }

      /* ---------- catalog ---------- */
      .ph-catalog{ max-width:1240px; margin:0 auto; padding:70px 28px 40px; perspective:1400px; }
      .ph-section-head{ display:flex; flex-direction:column; gap:18px; margin-bottom:34px; }
      .ph-section-head h2{ font-size:30px; }
      .ph-chips{ display:flex; gap:8px; flex-wrap:wrap; }
      .ph-chip{ background:var(--bg3); border:1px solid transparent; color:var(--text); font-size:13px; font-weight:600;
        padding:8px 16px; border-radius:100px; cursor:pointer; transition:all .2s ease; }
      .ph-chip:hover{ border-color:var(--orange); color:var(--orange2); }
      .ph-chip-active{ background:linear-gradient(135deg,var(--orange),var(--rust)); color:#fff; }

      .ph-grid{ display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:22px; }
      .ph-card{ position:relative; background:var(--bg2); border:1px solid var(--line); border-radius:18px; padding:18px; display:flex; flex-direction:column;
        transition:box-shadow .25s ease, border-color .25s ease; transform-style:preserve-3d; will-change:transform; }
      .ph-card:hover{ box-shadow:0 22px 40px rgba(179,58,14,0.2); border-color:rgba(255,138,61,0.45); }
      .ph-card-glare{ position:absolute; inset:0; border-radius:inherit; pointer-events:none; opacity:0; transition:opacity .3s ease;
        background:radial-gradient(circle at var(--mx,50%) var(--my,50%), rgba(255,255,255,0.55), transparent 55%); z-index:2; }
      .ph-card:hover .ph-card-glare{ opacity:1; }
      .ph-tag{ position:absolute; top:14px; left:14px; font-size:10.5px; font-weight:800; text-transform:uppercase; letter-spacing:0.04em;
        padding:5px 10px; border-radius:100px; z-index:3; }
      .ph-tag-new{ background:rgba(74,222,128,0.16); color:#4ADE80; }
      .ph-tag-hit{ background:rgba(255,138,61,0.18); color:var(--orange2); }
      .ph-tag-sale{ background:rgba(255,107,107,0.18); color:#FF6B6B; }
      .ph-card-media{ height:130px; border-radius:12px; background:linear-gradient(150deg,var(--bg3),var(--bg2)); display:flex; align-items:center; justify-content:center;
        margin-bottom:14px; overflow:hidden; transition:background .3s ease; transform:translateZ(20px); }
      .ph-card:hover .ph-card-media{ background:linear-gradient(150deg,rgba(255,90,31,0.24),rgba(255,90,31,0.06)); }
      .ph-card-icon-badge{ width:64px; height:64px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff;
        background:linear-gradient(135deg,var(--orange),var(--rust)); box-shadow:0 12px 26px rgba(255,90,31,0.35), inset 0 2px 3px rgba(255,255,255,0.3);
        transition:transform .3s cubic-bezier(.4,0,.2,1), box-shadow .3s ease; }
      .ph-card:hover .ph-card-icon-badge{ transform:scale(1.1) translateZ(10px) rotate(-6deg); box-shadow:0 18px 34px rgba(255,90,31,0.48), inset 0 2px 3px rgba(255,255,255,0.35); }
      .ph-card-cat{ font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--muted); margin-bottom:4px; }
      .ph-card-name{ font-family:'Oswald',sans-serif; font-size:17px; font-weight:600; margin-bottom:6px; }
      .ph-card-desc{ font-size:13px; color:var(--muted); line-height:1.5; margin-bottom:16px; flex:1; }
      .ph-card-bottom{ display:flex; align-items:center; justify-content:space-between; gap:10px; }
      .ph-price-block{ display:flex; flex-direction:column; }
      .ph-old-price{ font-family:'JetBrains Mono',monospace; font-size:11.5px; color:var(--muted); text-decoration:line-through; }
      .ph-price{ font-family:'JetBrains Mono',monospace; font-size:16.5px; font-weight:600; color:var(--orange2); }
      .ph-stock-low{ margin-top:8px; font-size:11px; color:#FF7A6E; font-weight:600; }
      .ph-loading, .ph-empty{ text-align:center; padding:60px 20px; color:var(--muted); font-size:14px; }

      /* ---------- why us ---------- */
      .ph-why{ max-width:1240px; margin:20px auto 0; padding:50px 28px; display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:24px; }
      .ph-why-item{ display:flex; gap:14px; align-items:flex-start; padding:22px; border-radius:16px; background:var(--bg3); transition:transform .25s ease, background .25s ease; }
      .ph-why-item:hover{ transform:translateY(-4px); background:rgba(255,90,31,0.12); }
      .ph-why-item svg{ color:var(--orange2); flex-shrink:0; margin-top:2px; }
      .ph-why-title{ font-weight:700; font-size:14.5px; margin-bottom:4px; }
      .ph-why-text{ font-size:12.5px; color:var(--muted); line-height:1.5; }

      /* ---------- footer ---------- */
      .ph-footer{ position:relative; margin-top:40px; background:linear-gradient(160deg,#181310,#2C1608); padding:56px 28px 20px; overflow:hidden; }
      .ph-footer-inner{ max-width:1240px; margin:0 auto; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:20px; position:relative; z-index:2; }
      .ph-footer-brand{ display:flex; align-items:center; gap:8px; color:#fff; font-family:'Oswald',sans-serif; font-size:18px; font-weight:600; }
      .ph-footer-contacts{ display:flex; gap:20px; flex-wrap:wrap; }
      .ph-footer-link{ display:flex; align-items:center; gap:8px; color:#e8ddd0; text-decoration:none; font-weight:600; font-size:14px; padding:8px 4px; transition:color .2s ease, transform .2s ease; }
      .ph-footer-link:hover{ color:var(--orange2); transform:translateY(-2px); }
      .ph-admin-toggle{ display:flex; align-items:center; gap:6px; background:rgba(255,255,255,0.06); border:1px solid var(--line); color:#a8998a;
        font-size:12px; padding:8px 14px; border-radius:9px; cursor:pointer; transition:all .2s ease; }
      .ph-admin-toggle:hover{ color:#fff; border-color:var(--orange); }
      .ph-footer-copy{ max-width:1240px; margin:36px auto 0; padding-top:20px; border-top:1px solid var(--line); text-align:center; color:#6b5d50; font-size:12px; position:relative; z-index:2; }

      /* ---------- overlay / drawer / modal ---------- */
      .ph-overlay{ position:fixed; inset:0; background:rgba(20,15,10,0.55); backdrop-filter:blur(3px); z-index:100; display:flex; justify-content:flex-end; animation:ph-fade .2s ease; }
      @keyframes ph-fade{ from{opacity:0;} to{opacity:1;} }
      .ph-drawer{ width:420px; max-width:92vw; height:100%; background:var(--bg2); display:flex; flex-direction:column; animation:ph-slide .3s cubic-bezier(.16,1,.3,1); box-shadow:-14px 0 40px rgba(0,0,0,0.2); }
      @keyframes ph-slide{ from{transform:translateX(100%);} to{transform:translateX(0);} }
      .ph-drawer-head{ display:flex; align-items:center; justify-content:space-between; padding:20px 22px; border-bottom:1px solid var(--line); }
      .ph-drawer-head h3{ display:flex; align-items:center; gap:8px; font-size:17px; }
      .ph-icon-btn{ background:none; border:none; cursor:pointer; color:var(--muted); width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; transition:all .2s ease; }
      .ph-icon-btn:hover{ background:rgba(239,68,68,0.15); color:#FF7A6E; }
      .ph-cart-items{ flex:1; overflow-y:auto; overscroll-behavior:contain; padding:12px 22px; display:flex; flex-direction:column; gap:12px; }
      .ph-cart-item{ display:flex; align-items:center; gap:12px; padding:10px; border-radius:12px; transition:background .2s ease; }
      .ph-cart-item:hover{ background:var(--bg3); }
      .ph-cart-item-icon{ width:44px; height:44px; display:flex; align-items:center; justify-content:center; color:var(--orange2); background:var(--bg3); border-radius:10px; flex-shrink:0; }
      .ph-cart-item-info{ flex:1; min-width:0; }
      .ph-cart-item-name{ font-size:13.5px; font-weight:600; }
      .ph-cart-item-price{ font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--muted); }
      .ph-qty{ display:flex; align-items:center; gap:8px; background:var(--bg3); border-radius:8px; padding:4px 8px; }
      .ph-qty button{ background:none; border:none; cursor:pointer; color:var(--orange2); display:flex; }
      .ph-qty span{ font-family:'JetBrains Mono',monospace; font-size:12.5px; min-width:14px; text-align:center; }
      .ph-drawer-foot{ padding:20px 22px; border-top:1px solid var(--line); }
      .ph-total-row{ display:flex; justify-content:space-between; font-family:'Oswald',sans-serif; font-size:17px; font-weight:600; margin-bottom:16px; }

      .ph-modal{ position:relative; margin:auto; width:640px; max-width:94vw; max-height:88vh; overflow-y:auto; overscroll-behavior:contain; background:var(--bg2); border-radius:22px; padding:34px; animation:ph-pop .28s cubic-bezier(.16,1,.3,1); }
      @keyframes ph-pop{ from{opacity:0; transform:scale(0.94) translateY(10px);} to{opacity:1; transform:scale(1) translateY(0);} }
      .ph-modal-close{ position:absolute; top:18px; right:18px; }

      .ph-steps{ display:flex; gap:0; margin-bottom:28px; }
      .ph-step{ flex:1; display:flex; align-items:center; gap:8px; font-size:12.5px; font-weight:700; color:var(--muted); padding-bottom:12px; border-bottom:3px solid var(--line); }
      .ph-step-num{ width:22px; height:22px; border-radius:50%; background:var(--line); color:var(--muted); display:flex; align-items:center; justify-content:center; font-size:11px; flex-shrink:0; transition:all .25s ease; }
      .ph-step-active{ color:var(--text); border-color:var(--orange); }
      .ph-step-active .ph-step-num{ background:linear-gradient(135deg,var(--orange),var(--rust)); color:#fff; }
      .ph-step-done .ph-step-num{ background:#22C55E; color:#0A0806; }
      .ph-step-body h3{ font-size:19px; margin-bottom:16px; }
      .ph-form-grid{ display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:6px; }
      .ph-field{ display:flex; flex-direction:column; gap:6px; font-size:12.5px; font-weight:700; color:var(--muted); position:relative; }
      .ph-field input, .ph-field textarea{ font-family:'Manrope',sans-serif; font-size:14px; font-weight:500; color:var(--text); border:1.5px solid var(--line);
        border-radius:10px; padding:11px 13px; outline:none; transition:border-color .2s ease, box-shadow .2s ease; background:var(--bg2); }
      .ph-field input:focus, .ph-field textarea:focus{ border-color:var(--orange); box-shadow:0 0 0 4px rgba(255,90,31,0.1); }
      .ph-field textarea{ resize:vertical; min-height:60px; }

      .ph-delivery-options{ display:flex; gap:10px; flex-wrap:wrap; margin-bottom:18px; }
      .ph-delivery-opt{ background:var(--bg3); border:1.5px solid transparent; color:var(--text); font-size:13px; font-weight:600; padding:10px 16px; border-radius:11px; cursor:pointer; transition:all .2s ease; }
      .ph-delivery-opt:hover{ border-color:var(--orange2); }
      .ph-delivery-opt-active{ background:linear-gradient(135deg,var(--orange),var(--rust)); color:#fff; }

      .ph-input-wrap{ display:flex; align-items:center; gap:8px; border:1.5px solid var(--line); border-radius:10px; padding:0 13px; transition:border-color .2s ease, box-shadow .2s ease; }
      .ph-input-wrap:focus-within{ border-color:var(--orange); box-shadow:0 0 0 4px rgba(255,90,31,0.1); }
      .ph-input-wrap svg{ color:var(--muted); flex-shrink:0; }
      .ph-input-wrap input{ border:none; padding:11px 0; flex:1; outline:none; font-size:14px; font-family:'Manrope',sans-serif; background:transparent; }
      .ph-disabled{ background:var(--bg3); opacity:0.7; }
      .ph-autocomplete{ position:relative; }
      .ph-dropdown{ position:absolute; top:calc(100% + 6px); left:0; right:0; background:var(--bg2); border:1px solid var(--line); border-radius:12px;
        box-shadow:0 16px 32px rgba(20,15,10,0.16); z-index:50; max-height:220px; overflow-y:auto; padding:6px; }
      .ph-option{ padding:9px 12px; border-radius:8px; font-size:13.5px; cursor:pointer; transition:background .15s ease; }
      .ph-option-hi{ background:var(--bg3); color:var(--orange2); }
      .ph-option-muted{ color:var(--muted); cursor:default; font-size:12.5px; }
      .ph-option-error{ color:#FF7A6E; white-space:normal; line-height:1.4; }
      .ph-spinner{ width:14px; height:14px; border-radius:50%; border:2px solid var(--line); border-top-color:var(--orange); animation:ph-spin .7s linear infinite; flex-shrink:0; }
      @keyframes ph-spin{ to{ transform:rotate(360deg); } }
      .ph-field-hint{ font-size:11px; font-weight:600; color:var(--muted); margin-top:2px; display:flex; align-items:center; gap:6px; }
      .ph-dot{ width:7px; height:7px; border-radius:50%; flex-shrink:0; }
      .ph-dot-on{ background:#4ADE80; box-shadow:0 0 6px rgba(74,222,128,0.7); }
      .ph-dot-off{ background:var(--gold); box-shadow:0 0 6px rgba(255,195,105,0.6); }
      .ph-np-box{ background:var(--bg3); border-radius:14px; padding:16px 18px; display:flex; flex-direction:column; gap:10px; }
      .ph-np-box-title{ display:flex; align-items:center; gap:7px; font-weight:700; font-size:13.5px; color:var(--orange2); }
      .ph-np-box p{ font-size:12px; color:var(--muted); line-height:1.6; margin:0; }
      .ph-np-divider{ height:1px; background:var(--line); margin:2px 0; }
      .ph-np-hint{ font-style:italic; opacity:0.85; }
      .ph-diag{ display:flex; flex-direction:column; gap:12px; align-items:flex-start; }
      .ph-diag-results{ display:flex; flex-direction:column; gap:10px; width:100%; }
      .ph-diag-row{ border-radius:10px; padding:12px 14px; border:1px solid var(--line); }
      .ph-diag-ok{ background:rgba(74,222,128,0.08); border-color:rgba(74,222,128,0.3); }
      .ph-diag-fail{ background:rgba(255,122,110,0.08); border-color:rgba(255,122,110,0.35); }
      .ph-diag-row-head{ display:flex; align-items:center; gap:8px; font-size:12.5px; margin-bottom:6px; }
      .ph-diag-ok .ph-diag-row-head{ color:#4ADE80; }
      .ph-diag-fail .ph-diag-row-head{ color:#FF7A6E; }
      .ph-diag-row-detail{ font-size:11.5px; color:var(--muted); display:flex; flex-direction:column; gap:3px; }
      .ph-diag-row-detail code{ font-family:'JetBrains Mono',monospace; font-size:11px; color:var(--text); word-break:break-all; }
      .ph-np-status{ display:flex; align-items:center; gap:6px; font-size:12px; font-weight:700; }
      .ph-np-on{ color:#4ADE80; }
      .ph-np-off{ color:var(--gold); }

      .ph-summary{ background:var(--bg3); border-radius:14px; padding:16px 18px; margin-bottom:18px; display:flex; flex-direction:column; gap:9px; }
      .ph-summary-row{ display:flex; justify-content:space-between; font-size:13.5px; }
      .ph-summary-row span{ color:var(--muted); }

      .ph-step-nav{ display:flex; justify-content:space-between; margin-top:26px; gap:12px; }
      .ph-step-nav .ph-btn-primary{ margin-left:auto; }

      .ph-order-success{ text-align:center; padding:20px 10px 4px; }
      .ph-success-icon{ width:56px; height:56px; border-radius:50%; background:linear-gradient(135deg,#3FBF6C,#1F8F4C); color:#fff; display:flex; align-items:center; justify-content:center; margin:0 auto 18px; }
      .ph-order-success h3{ font-size:22px; margin-bottom:10px; }
      .ph-order-success p{ color:var(--muted); font-size:14px; line-height:1.6; max-width:420px; margin:0 auto 16px; }
      .ph-success-box{ background:var(--bg3); border-radius:12px; padding:14px 18px; display:flex; flex-direction:column; gap:6px; margin:0 auto 16px; max-width:320px; font-size:13.5px; }
      .ph-success-hint{ font-size:12.5px !important; }

      /* ---------- admin ---------- */
      .ph-admin-login{ text-align:center; padding:26px 10px 6px; display:flex; flex-direction:column; align-items:center; gap:14px; }
      .ph-admin-login svg{ color:var(--orange2); }
      .ph-admin-login input{ width:260px; max-width:100%; border:1.5px solid var(--line); border-radius:10px; padding:11px 14px; font-size:14px; outline:none; text-align:center; background:var(--bg2); color:var(--text); }
      .ph-admin-login input:focus{ border-color:var(--orange); }
      .ph-pw-error{ display:flex; align-items:center; gap:6px; color:#FF7A6E; font-size:12.5px; }

      .ph-admin-modal{ width:920px; max-width:96vw; padding:0; overflow:hidden; }
      .ph-admin-shell{ display:flex; height:88vh; max-height:88vh; min-height:0; }
      .ph-admin-sidebar{ width:210px; flex-shrink:0; background:var(--bg); border-right:1px solid var(--line); padding:24px 16px; display:flex; flex-direction:column; gap:22px; min-height:0; overflow-y:auto; }
      .ph-admin-brand{ display:flex; align-items:center; gap:10px; padding:0 4px; }
      .ph-admin-brand-name{ font-family:'Oswald',sans-serif; font-size:15px; font-weight:600; color:var(--text); }
      .ph-admin-brand-sub{ font-size:10.5px; color:var(--muted); }
      .ph-admin-nav{ display:flex; flex-direction:column; gap:4px; flex:1; }
      .ph-admin-nav button{ display:flex; align-items:center; gap:10px; background:none; border:none; color:var(--muted); font-size:13.5px; font-weight:600;
        padding:11px 12px; border-radius:10px; cursor:pointer; text-align:left; transition:all .18s ease; position:relative; }
      .ph-admin-nav button:hover{ background:var(--bg3); color:var(--text); }
      .ph-admin-nav-active{ background:linear-gradient(135deg,var(--orange),var(--rust)) !important; color:#fff !important; box-shadow:0 8px 18px rgba(255,90,31,0.3); }
      .ph-nav-badge{ margin-left:auto; background:var(--gold); color:#221B15; font-size:10.5px; font-weight:800; padding:1px 7px; border-radius:100px; }
      .ph-admin-logout{ display:flex; align-items:center; gap:8px; background:var(--bg3); border:1px solid var(--line); color:var(--muted); font-size:12.5px; font-weight:700;
        padding:10px 12px; border-radius:10px; cursor:pointer; transition:all .2s ease; }
      .ph-admin-logout:hover{ color:#FF7A6E; border-color:#FF7A6E; }

      .ph-admin-main{ flex:1; min-width:0; min-height:0; padding:26px 28px; overflow-y:auto; overscroll-behavior:contain; display:flex; flex-direction:column; gap:20px; }
      .ph-admin-stats{ display:grid; grid-template-columns:repeat(4,1fr); gap:12px; }
      .ph-stat-card{ background:var(--bg3); border:1px solid var(--line); border-radius:13px; padding:13px 14px; display:flex; align-items:flex-start; gap:10px; }
      .ph-stat-card svg{ color:var(--orange2); margin-top:2px; flex-shrink:0; }
      .ph-stat-card span{ display:block; font-size:10px; color:var(--muted); text-transform:uppercase; letter-spacing:0.03em; margin-bottom:3px; }
      .ph-stat-card b{ font-family:'JetBrains Mono',monospace; font-size:16px; color:var(--text); }
      .ph-stat-accent{ border-color:rgba(255,90,31,0.35); background:rgba(255,90,31,0.08); }
      .ph-admin-panel-title{ display:flex; align-items:center; gap:8px; font-family:'Oswald',sans-serif; font-size:17px; font-weight:600; color:var(--text); }
      .ph-admin-panel-title svg{ color:var(--orange2); }
      .ph-admin-body{ display:flex; flex-direction:column; gap:14px; }

      .ph-order-card{ background:var(--bg3); border:1px solid var(--line); border-radius:14px; padding:16px 18px; }
      .ph-order-top{ display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; gap:10px; }
      .ph-order-date{ display:block; font-size:11px; color:var(--muted); font-family:'JetBrains Mono',monospace; margin-top:2px; }
      .ph-status-label{ display:flex; align-items:center; gap:8px; font-size:10.5px; color:var(--muted); text-transform:uppercase; letter-spacing:0.03em; }
      .ph-status{ border:none; border-radius:100px; padding:6px 12px; font-size:11.5px; font-weight:700; cursor:pointer; }
      .ph-status-new{ background:rgba(255,184,77,0.22); color:var(--gold); }
      .ph-status-confirmed{ background:rgba(96,165,250,0.2); color:#60A5FA; }
      .ph-status-shipped{ background:rgba(167,139,250,0.22); color:#A78BFA; }
      .ph-status-done{ background:rgba(74,222,128,0.2); color:#4ADE80; }
      .ph-order-grid{ display:grid; grid-template-columns:1fr 1fr; gap:6px 16px; font-size:12.5px; margin-bottom:10px; }
      .ph-order-grid span{ color:var(--muted); display:block; font-size:10.5px; text-transform:uppercase; letter-spacing:0.03em; }
      .ph-order-items{ background:var(--bg2); border-radius:10px; padding:10px 12px; display:flex; flex-direction:column; gap:4px; font-size:12.5px; margin-bottom:8px; }
      .ph-order-comment{ font-size:12px; color:var(--muted); font-style:italic; margin-bottom:8px; }
      .ph-order-bottom{ display:flex; justify-content:space-between; align-items:center; }

      .ph-product-edit{ display:flex; gap:14px; align-items:flex-start; background:var(--bg3); border:1px solid var(--line); border-radius:14px; padding:16px; }
      .ph-product-edit-icon{ width:40px; height:40px; border-radius:10px; background:var(--bg2); color:var(--orange2); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .ph-product-edit-fields{ flex:1; display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; }
      .ph-mini-field{ display:flex; flex-direction:column; gap:5px; }
      .ph-mini-field span{ font-size:10px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:0.03em; }
      .ph-mini-field-wide{ grid-column:1 / -1; }
      .ph-product-edit-fields input, .ph-product-edit-fields select, .ph-product-edit-fields textarea{
        border:1.5px solid var(--line); border-radius:8px; padding:8px 10px; font-size:12.5px; font-family:'Manrope',sans-serif; outline:none; background:var(--bg2); color:var(--text); }
      .ph-product-edit-fields textarea{ min-height:40px; resize:vertical; }
      .ph-product-edit-fields input:focus, .ph-product-edit-fields select:focus, .ph-product-edit-fields textarea:focus{ border-color:var(--orange); }

      .ph-saved-note{ display:flex; align-items:center; gap:6px; color:#4ADE80; font-size:12.5px; font-weight:700; }

      @media (max-width: 900px){
        .ph-nav{ display:none; }
        .ph-hero-title{ font-size:36px; }
        .ph-form-grid{ grid-template-columns:1fr; }
        .ph-order-grid{ grid-template-columns:1fr; }
        .ph-admin-shell{ flex-direction:column; height:auto; max-height:92vh; }
        .ph-admin-sidebar{ width:100%; flex-direction:row; align-items:center; padding:14px 16px; }
        .ph-admin-nav{ flex-direction:row; overflow-x:auto; }
        .ph-admin-stats{ grid-template-columns:1fr 1fr; }
        .ph-product-edit-fields{ grid-template-columns:1fr 1fr; }
      }
      @media (prefers-reduced-motion: reduce){
        .ph-root *{ animation:none !important; transition:none !important; }
      }
    `}</style>
  );
}
